// experience js
jQuery(function($) {
		
	$(window).on("load", function(){
		
		if ( $(".prod-top-slider").length > 0 ) {
			$(".prod-top-slider").flexslider({
				animation: "slide"
				, animationLoop: true
				, slideshow : false
				, touch	: true
				, prevText : "이전"
				, nextText : "다음"
				, controlNav : "thumbnails"
				, start : function(s){
					$(".prod-top-slider").removeClass("not-load");
					
					try {
						s.slides.eq(s.currentSlide).find('a').removeAttr('tabindex')
						.end().find("button").removeAttr("tabindex")
						.end().siblings().find("a").attr('tabindex', -1)
						.end().find("button").attr('tabindex', -1);
					} catch (e) {
						// TODO: handle exception
					}
					
					$(".prod-top-slider .flex-control-thumbs li img").each(function(idx){
						$(this).wrap("<button onclick='fnProdTopSliderPaging("+ idx +");'></button>");
					});
					
				}
				, after : function(s) {
					
					try {
						s.slides.eq(s.currentSlide).find('a').removeAttr('tabindex')
						.end().find("button").removeAttr("tabindex")
						.end().siblings().find("a").attr('tabindex', -1)
						.end().find("button").attr('tabindex', -1);
					} catch (e) {
						// TODO: handle exception
					}
					
				}
			});
		}
		
		if ( $(".product-list1").length > 0 ) {
			$(".product-list1").flexslider({
				animation: "slide"
				, animationLoop: true
				, slideshow : false
				, prevText : "이전"
				, nextText : "다음"
				, start : function(s){
					$(".product-list1").removeClass("not-load");
					
					try {
						s.slides.eq(s.currentSlide).find('a').removeAttr('tabindex')
						.end().find("button").removeAttr("tabindex")
						.end().siblings().find("a").attr('tabindex', -1)
						.end().find("button").attr('tabindex', -1);
					} catch (e) {
						// TODO: handle exception
					}
					
				}
				, after : function(s) {

					try {
						s.slides.eq(s.currentSlide).find('a').removeAttr('tabindex')
						.end().find("button").removeAttr("tabindex")
						.end().siblings().find("a").attr('tabindex', -1)
						.end().find("button").attr('tabindex', -1);
					} catch (e) {
						// TODO: handle exception
					}
					
				}
			});				
		}
		
		if ( $(".slider-gift").length > 0 ) {
			$(".slider-gift").flexslider({
				animation: "slide"
				, animationLoop: true
				, slideshow : false
				, prevText : "이전"
				, nextText : "다음"
				, start : function(s){
					$(".slider-gift").removeClass("not-load");

					try {
						s.slides.eq(s.currentSlide).find('a').removeAttr('tabindex')
						.end().find("button").removeAttr("tabindex")
						.end().siblings().find("a").attr('tabindex', -1)
						.end().find("button").attr('tabindex', -1);
					} catch (e) {
						// TODO: handle exception
					}
					
				}
				, after : function(s) {

					try {
						s.slides.eq(s.currentSlide).find('a').removeAttr('tabindex')
						.end().find("button").removeAttr("tabindex")
						.end().siblings().find("a").attr('tabindex', -1)
						.end().find("button").attr('tabindex', -1);
					} catch (e) {
						// TODO: handle exception
					}
					
				}
			});
		}
		
		if ( $(".slider-tip").length > 0 ) {
			$(".slider-tip").flexslider({
				animation: "slide"
				, animationLoop: true
				, slideshow : false
				, prevText : "이전"
				, nextText : "다음"
				, start : function(s){
					$(".slider-tip").removeClass("not-load");

					try {
						s.slides.eq(s.currentSlide).find('a').removeAttr('tabindex')
						.end().find("button").removeAttr("tabindex")
						.end().siblings().find("a").attr('tabindex', -1)
						.end().find("button").attr('tabindex', -1);
					} catch (e) {
						// TODO: handle exception
					}
					
				}
				, after : function(s) {

					try {
						s.slides.eq(s.currentSlide).find('a').removeAttr('tabindex')
						.end().find("button").removeAttr("tabindex")
						.end().siblings().find("a").attr('tabindex', -1)
						.end().find("button").attr('tabindex', -1);
					} catch (e) {
						// TODO: handle exception
					}
					
				}
			});
		}
		
		if ( $(".relprod-slier").length > 0 ) {
			
			$(".relprod-slier").flexslider({
				animation: "slide"
				, animationLoop: false
				, slideshow : false
				, prevText : "이전"
				, nextText : "다음"
				, itemWidth : 240
				, move: 2
				, minItems: 2
				, maxItems: 5
				, start : function(s){
					$(".relprod-slier").removeClass("not-load");
					
					try {
						if ( s.currentSlide == 0 ) {
							$(s.slides).each(function(idx){
								if ( idx < 5 ) {
									$(this).find('a').removeAttr('tabindex');
								} else {
									$(this).find('a').attr('tabindex', -1);
								}
							});
						} else {
							$(s.slides).each(function(idx){
								if ( idx >= (s.currentSlide * 2) && idx < s.currentSlide + 5 ) {
									$(this).find('a').removeAttr('tabindex');
								} else {
									$(this).find('a').attr('tabindex', -1);
								}
							});
						}
					} catch (e) {
						// TODO: handle exception
					}
					
				}
				, after : function(s) {

					try {
						if ( s.currentSlide == 0 ) {
							$(s.slides).each(function(idx){
								if ( idx < 5 ) {
									$(this).find('a').removeAttr('tabindex');
								} else {
									$(this).find('a').attr('tabindex', -1);
								}
							});
						} else {
							$(s.slides).each(function(idx){
								if ( idx >= (s.currentSlide * 2) && idx < (s.currentSlide * 2) + 5 ) {
									$(this).find('a').removeAttr('tabindex');
								} else {
									$(this).find('a').attr('tabindex', -1);
								}
							});
						}
					} catch (e) {
						// TODO: handle exception
					}
					
				}
				
			});
		}
					
	});
	
	// 레이어 팝업들
	if ( $(".pop2-area").length > 0 ) {
		$(".btn-pop-close", $(".pop2-area")).on("focusout", function(){
			fnClosePopImg("pop2-area");
			$("." + $(this).data("focusTo")).eq($(this).data("focusEq")).focus();
		});
	}
	
	if ( $(".pop-bp-area").length > 0 ) {
		$(".btn-pop-close", $(".pop-bp-area")).on("focusout", function(){
			fnClosePopImg("pop-bp-area");
			$("." + $(this).data("focusTo")).eq($(this).data("focusEq")).focus();
		});
	}
	
	if ( $(".pop-info2").length > 0 ) {
		$(".btn-pop-close", $(".pop-info2")).on("focusout", function(){
			fnClosePopImg("pop-info2");
			$("." + $(this).data("focusTo")).eq($(this).data("focusEq")).focus();
		});
	}
	
	if ( $(".pop1-area").length > 0 ) {
		$(".btn-pop-close", $(".pop1-area")).on("focusout", function(){
			fnClosePopImg("pop1-area");
			$("." + $(this).data("focusTo")).eq($(this).data("focusEq")).focus();
		});
	}
	
	if ( $(".pop-btn-sns2-area").length > 0 ) {
		$(".btn-pop-close", $(".pop-btn-sns2-area")).on("focusout", function(){
			fnClosePopImg("pop-btn-sns2-area");
			$("." + $(this).data("focusTo")).eq($(this).data("focusEq")).focus();
		});
	}
	
	// 상세보기 탭
	$(".sect-product-view1 .tab-area1 nav > a").on("click", function(e){
		e.preventDefault();
		var idx_tab = $(".sect-product-view1 .tab-area1 nav > a").index($(this));
		$(this).addClass("on").siblings().removeClass("on");
		$(".detail-desc-area").eq(idx_tab).removeClass("disn").siblings(".detail-desc-area").addClass("disn");
	});
	
	// 상세보기 중 상품 리뷰 탭
	$(".sect-product-view1 .tab-review-area .tab-review button").on("click", function(){
		$(this).parent().addClass("on").siblings(".tab-review").removeClass("on");
		var idx_tab = $(".sect-product-view1 .tab-review-area .tab-review button").index(this);
		$(".sect-product-view1 .detail-desc-area.desc-review .review-list-wrap").eq(idx_tab).removeClass("disn").siblings(".review-list-wrap").addClass("disn");
	});
	
	$(".nav-list.nav-list1 li a").on("click", function(e){
		e.preventDefault();
		var tmp_idx = $(".nav-list.nav-list1 li a").index($(this));
		$(this).addClass("on").parent().siblings().find("a").removeClass("on");
		$("#srch_gbn").find("option").eq(tmp_idx).prop("selected", true);
		$("#srch_gbn").trigger("change");
	});
	$("#srch_gbn").on("change", function(){
		var tmp_idx = $(this).find("option:selected").index();
		$(".nav-list.nav-list1 li a").eq(tmp_idx).addClass("on").parent().siblings().find("a").removeClass("on");
	});
	
	$(".list-prod .prod-panel .qview").on("click", function(){
		fnPopImg($(this), 'pop2-area');
	});
	
});

function fnProdTopSliderPaging(idx) {
	$(".prod-top-slider").flexslider(idx);
}
function fnMorenIgredient(obj_this) {
	var $me = $(obj_this);
	var $next = $me.next(".more-ingredient");
	if ( $next.hasClass("disn") ) {
		$next.removeClass("disn");
		$me.text("내용접기 -");
	} else {
		$next.addClass("disn");
		$me.text("펼쳐보기 +");
	}
}
