// experience js
jQuery(function($) {
		
	$(window).on("load", function(){
		
		if ( $(".event-slider1").length > 0 ) {
			$(".event-slider1").flexslider({
				animation: "slide"
				, animationLoop: true
				, slideshow : false
				, prevText : "이전"
				, nextText : "다음"
				, start : function(s){
					$(".event-slider1").removeClass("not-load");
					
					try {
						s.slides.eq(s.currentSlide).find('a').removeAttr('tabindex')
						.end().find("button").removeAttr("tabindex")
						.end().siblings().find("a").attr('tabindex', -1)
						.end().find("button").attr('tabindex', -1);
					} catch (e) {
						console.log(e.message);
					}
					
				}
				, after : function(s) {

					try {
						s.slides.eq(s.currentSlide).find('a').removeAttr('tabindex')
						.end().find("button").removeAttr("tabindex")
						.end().siblings().find("a").attr('tabindex', -1)
						.end().find("button").attr('tabindex', -1);
					} catch (e) {
						console.log(e.message);
					}
					
				}
			});
		}
		
	});
	
});