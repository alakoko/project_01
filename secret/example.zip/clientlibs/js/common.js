var scroll_el_width;
var scroll_inner_el_width;
var max_scroll;
// common js
jQuery(document).ready(function($){
	
	// 슬라이더 옵션
	if( $.flexslider !== undefined ) {
		$.extend($.flexslider.defaults, {
			/*namespace: "",
			controlsContainer: ".controls",
			animation: "slide",
			animationLoop: false,
			itemWidth: 310,
			itemMargin: 20,
			move: 3,
			useCSS : false,*/
			start: function(s) {
				/*var $filter = (s.currentSlide == 0) ? ':lt('+ s.move +')' : ':lt('+ ((s.currentSlide + 1) * s.move)  +'):gt(' + ((s.currentSlide * s.move) - 1) + ')';

				$(s.slides).filter(':not(' + $filter + ')').find('a').attr('tabindex', -1);
				$(s.slides).filter($filter).find('a').removeAttr('tabindex');*/
			},
			after:function(s) {
				/*var $filter = (s.currentSlide == 0) ? ':lt('+ s.move +')' : ':lt('+ ((s.currentSlide + 1) * s.move)  +'):gt(' + ((s.currentSlide * s.move) - 1) + ')';

				$(s.slides).filter(':not(' + $filter + ')').find('a').attr('tabindex', -1);
				$(s.slides).filter($filter).find('a').removeAttr('tabindex');*/
			}
		});
	}
	
	// 브레드 크럼
	$("#breadcrumb").sticky({topSpacing:0});
	$("#breadcrumb .arr-bottom").on("click", function(){
		$(this).addClass("disn").siblings(".arr-top").removeClass("disn").siblings(".crumb-menu").removeClass("disn");
	});
	$("#breadcrumb .arr-top").on("click", function(){
		$(this).addClass("disn").siblings(".arr-bottom").removeClass("disn").siblings(".crumb-menu").addClass("disn");
	});
	$("#breadcrumb .crumb.arr-wrap > a").on("click", function(e){
		e.preventDefault();
		var $par 		= $(this).parent();
		var $crumb_menu = $(".crumb-menu", $par);
		if ( $crumb_menu.hasClass("disn") == true ) {
			$(".arr-bottom", $par).trigger("click");
		} else {
			$(".arr-top", $par).trigger("click");
		}
	});
	
	// 스크롤시 헤더 배경 변경
	$(window).on("scroll", function(){
		
		if ($(window).scrollTop() > 50) {
			$("#wrap").addClass("header-trans");
		} else {
			$("#wrap").removeClass("header-trans");
		}
		if ($(window).scrollTop() > 191) {
			$("#breadcrumb .shadow").removeClass("disn");
		} else {
			$("#breadcrumb .shadow").addClass("disn");
		}
		
	});
	
	// 모바일, 테블릿 상단 메뉴
	$("#header .btn-hamburger").on("click", function(e){
		e.preventDefault();
		var $side = $("#side");
		if ($side.is(":visible") == false) {
			fnMobMenu();
		}/* else {
			fnMobMenuClose();
		}*/
	});
	$("#side .btn-close").on("click", function(e){
		e.preventDefault();
		fnMobMenuClose();
	});
	// 3depth 메뉴 보이기/숨기기
	$(".side-nav .menu-d2.btn-arr-wrap .arr-bottom").on("click", function(e){
		e.preventDefault();
		var $menud3 = $(this).siblings(".menu-d3-list");
		var $menud3_list = $(".menu-d3-list");
		var menud3_idx = $menud3_list.index($menud3);
		
		if ($menud3.is(":visible") == false) {
			$(".menu-d3-list").not(":eq("+ menud3_idx +")").stop().slideUp(600).addClass("disn");
			$(".menu-d2 .btn-arr.arr-top").addClass("disn").siblings(".arr-bottom").removeClass("disn");
			$(this).addClass("disn").siblings(".btn-arr").removeClass("disn");
			$menud3.stop().slideDown(600);
		}
	});
	$(".side-nav .menu-d2.btn-arr-wrap .arr-top").on("click", function(e){
		e.preventDefault();
		var $menud3 = $(this).siblings(".menu-d3-list");
		var $menud3_list = $(".menu-d3-list");
		var menud3_idx = $menud3_list.index($menud3);
		
		if ($menud3.is(":visible") == true) {
			$(".menu-d2 .btn-arr.arr-top").addClass("disn").siblings(".arr-bottom").removeClass("disn");
			$(".menu-d3-list").slideUp(600).addClass("disn");
		}
	});
		
	// pc gnb
	var $menu = $(".gmenu-d1-list");
	
	$menu.menuAim({
		activate: activateSubmenu,
		deactivate: deactivateSubmenu,
		exitMenu: function(){return true;}
	});

	function activateSubmenu(row) {
		var $row = $(row),
			 submenuId = $row.data("submenuId"),
			 $submenu = $("#" + submenuId);

		$row.addClass("active");
		$row.find(".gmenu-d1").removeClass("under").addClass("over").parent().siblings().find(".gmenu-d1").removeClass("over").addClass("under");
	}

	function deactivateSubmenu(row) {
		var $row = $(row),
			 submenuId = $row.data("submenuId"),
			 $submenu = $("#" + submenuId);

		$row.removeClass("active");
		$row.find(".gmenu-d1").removeClass("over").removeClass("under").parent().siblings().find(".gmenu-d1").removeClass("over").removeClass("under");
	}
	
	var $menu2 = $(".gmenu-d2-list");
	
	$menu2.menuAim({
		activate: activateSubmenu2,
		deactivate: deactivateSubmenu2,
		exitMenu: function(){return true;}
	});

	function activateSubmenu2(row) {
		var $row = $(row),
			 submenuId = $row.data("submenuId"),
			 $submenu = $("#" + submenuId);

		$row.addClass("active");
		$row.find(".gmenu-d2").addClass("over").parent().siblings().find(".gmenu-d2").removeClass("over");
	}

	function deactivateSubmenu2(row) {
		var $row = $(row),
			 submenuId = $row.data("submenuId"),
			 $submenu = $("#" + submenuId);

		$row.removeClass("active");
		$row.find(".gmenu-d2").removeClass("over").parent().siblings().find(".gmenu-d2").removeClass("over");
	}
	
	$("#header .logo").on("focusin", function(){
		$("#gnb .gmenu-d1-list > li").removeClass("active");
		$("#gnb .gmenu-d1-list .gmenu-d1").removeClass("over").removeClass("under");
		$("#gnb .gmenu-d2-list > li").removeClass("active");
		$("#gnb .gmenu-d2-list .gmenu-d2").removeClass("over");
		$("#gnb .gmenu-d3-list .gmenu-d3").removeClass("over");
	});
	$("#gnb .gmenu-d1").on("focusin", function(){
		var $me = $(this);
		setTimeout(function(){
			$me.addClass("over").removeClass("under").parent().siblings("li").find(".gmenu-d1").removeClass("over").addClass("under")
				.end().end().end().parent().addClass("active").siblings().removeClass("active");
		}, 10);
	});
	$("#gnb .gmenu-d2").on("focusin", function(){
		var $me = $(this);
		setTimeout(function(){
			$me.addClass("over").parent().siblings("li").find(".gmenu-d2").removeClass("over")
				.end().end().end().parent().addClass("active").siblings().removeClass("active");
		}, 10);
	});
	$("#gnb .gmenu-d3-list").on("mouseleave", function(){
		$(this).addClass("disn").find(".gmenu-d3").removeClass("over");
	});
	$("#gnb .gmenu-d3").on("mouseenter focusin", function(){
		$(this).addClass("over").siblings().removeClass("over");
	});
	$("#header .header-right .util-pc .first").on("focusin", function(){
		$("#gnb .gmenu-d1-list > li").removeClass("active");
		$("#gnb .gmenu-d1-list .gmenu-d1").removeClass("over").removeClass("under");
		$("#gnb .gmenu-d2-list > li").removeClass("active");
		$("#gnb .gmenu-d2-list .gmenu-d2").removeClass("over");
		$("#gnb .gmenu-d3-list .gmenu-d3").removeClass("over");
	});
	
	
	// 셀렉트 박스
	fnSelectedText($(".select1-box .select1"));
	$(".select1-box .select1").each(function(){
		fnSelectedText($(this));
	});
	$(".select1-box .select1").on("change", function(){
		fnSelectedText($(this));
	});
	
	// 사이트맵 하위메뉴 보이기/숨기기
	$(".sec-sitemap .list2 .arr-bottom").on("click", function(e){
		e.preventDefault();
		var $menus = $(this).siblings(".list-d2");
		if ($menus.is(":visible") == false) {
			$(this).addClass("disn").siblings(".btn-arr").removeClass("disn");
			$menus.stop().slideDown(600);
		}
	});
	$(".sec-sitemap .list2 .arr-top").on("click", function(e){
		e.preventDefault();
		var $menus = $(this).siblings(".list-d2");
		if ($menus.is(":visible") == true) {
			$(this).addClass("disn").siblings(".btn-arr").removeClass("disn");
			$menus.stop().slideUp(600);
		}
	});
		
	// 콤마 패턴
	fnComma();
	
    //breadcrumb 4depth click event
    $(".crumb-menu-list li a").on("click", function(){
       var tmp_idx = $(".crumb-menu-list li a").index($(this));
       $("#srch_gbn").find("option").eq(tmp_idx).prop("selected", true);
       $("#srch_gbn").trigger("change");
    });
    
    // 케어 솔루션
	fnCalTabScroll();
	$(window).on("resize", function(){
		fnCalTabScroll();
	});
	$("#header .btn-util.care, #header .search-wrap .btn-care").on("click", function(e){
		e.preventDefault();
		fnCareSolution();
	});
	
});

//모바일, 테블릿 상단 메뉴
function fnMobMenu() {
	$("body").addClass("side-open");
	$("#side").stop().fadeIn(300).find(".side-inner").removeClass("disn").stop().animate({
		"left" : 0
	}, 600).removeClass("disn");
}
function fnMobMenuClose() {
	$("#side .side-inner").scrollTop(0);
	$(".side-inner").stop().animate({
		"left" : $(window).width() * -1
	}, 400, function(){
		$(this).css({
			"left" : "-100%"
		}).addClass("disn").parent().stop().fadeOut(200);
		$("body").removeClass("side-open");
	})
}

// 셀렉트 박스
function fnSelectedText($obj_sel) {
	var sel_text = $obj_sel.find("option:selected").text();
	$obj_sel.parent().find(".selected-text").text(sel_text);
}

function fnPopImg(obj_this, pop_area, gbn) {
	var $me 		= $(obj_this);
	var me_class	= $me.attr("class").split(" ")[0];
	var me_idx		= $("." + me_class).index($me);
	var $img_from 	= $me.parent().find("img");
	var img_src 	= $img_from.attr("src");
	var img_alt 	= $img_from.attr("alt");
	var new_img 	= "<img src='"+ img_src +"' alt='"+ img_alt +"' />" 
	
	if (gbn != 1 && gbn != 2 && gbn != 3) {
		$("." + pop_area).find(".img-wrap").html(new_img);
	}
	
	$("." + pop_area).removeClass("disn").focus().find(".btn-pop-close").data({
		"focusTo" : me_class
		, "focusEq" : me_idx
	});
	
	if (gbn != 1 && gbn != 3) {
		$("body").addClass("side-open");
	}
}
function fnPopImg2(obj_this, pop_area) {
	var $me 		= $(obj_this);
	var me_class	= $me.attr("class").split(" ")[0];
	var me_idx		= $("." + me_class).index($me);

	$(".pop-info2").eq(me_idx).removeClass("disn").end().not(":eq("+ me_idx +")").addClass("disn");
	
	$("." + pop_area).removeClass("disn").focus().find(".btn-pop-close").data({
		"focusTo" : me_class
		, "focusEq" : me_idx
	});
	
}
function fnClosePopImg(pop_area) {
	$("." + pop_area).addClass("disn");
	$("body").removeClass("side-open");
}

//콤마찍기
function fnComma() {
    $(".price-pattern-comma").each(function(){
    	var str = String($(this).text());
    	$(this).text( str.replace(/(\d)(?=(?:\d{3})+(?!\d))/g, '$1,') );
    });
}
// 케어 솔루션
function fnCareSolution() {
	
	$.getScript("/kr/ko/clientlibs/care.js", function(){
	
		$("body").addClass("side-open");
		// .sect-pop-casol
		if ( $(".pop-casol").length < 1 ) {
			var $el_tmp = $("<div class='pop-casol disn'></div>");
			$("#container").append($el_tmp);
			$(".pop-casol").html(pop_casol_str).removeClass("disn").attr("tabindex", 0).focus();
			fnCalTabScroll();
			$(".pop-casol .btn-pop-close").on("focusout", function(){
				fnClosePopCasol();
			});
			
		} else {
			if ( $(".pop-casol .sect-pop-casol").length < 1 ) {
				$(".pop-casol").html(pop_casol_str).removeClass("disn").attr("tabindex", 0).focus();
				fnCalTabScroll();
				$(".pop-casol .btn-pop-close").on("focusout", function(){
					fnClosePopCasol();
				});
			} else {
				$(".pop-casol").removeClass("disn").attr("tabindex", 0).focus();
				fnCalTabScroll();
			}
		}
	
	});
	
}
function fnClosePopCasol() {
	$(".pop-casol").addClass("disn").removeAttr("tabindex");
	$("body").removeClass("side-open");
	if ( $(".mediack-desktop:visible").length > 0 ) {
		$("#header .search-wrap .btn-care").focus();
	} else {
		$("#header .btn-util.care").focus();
	}
}
function fnCalTabScroll() {
	scroll_el_width = $(".casol-tab-list-wrap").width();
	scroll_inner_el_width = $(".casol-tab-list-wrap .casol-tab-list").width();
	max_scroll = scroll_inner_el_width - scroll_el_width; 
}
function fnCasolTabScroll() {
	
	var $stroll_el = $(".pop-casol .casol-tab-list-wrap");
	var tmp_scroll_point = $stroll_el.scrollLeft();
	var $arr_left = $stroll_el.parent().find(".arr-left");
	var $arr_right = $stroll_el.parent().find(".arr-right");
	console.log()
	if ( tmp_scroll_point == 0 ) {
		$arr_left.removeClass("on");
	} else if ( tmp_scroll_point > 0 && tmp_scroll_point < max_scroll ) {
		$arr_left.addClass("on");
		$arr_right.addClass("on");
	} else if ( tmp_scroll_point == max_scroll ) {
		$arr_right.removeClass("on");
	}
	
}
function fnCasolTabClick() {
	$(".pop-casol .casol-tab-list a").on("click", function(e){
		e.preventDefault();
		$(this).parent().removeClass("on").siblings().addClass("on");
	});
}
function fnCasolHeaderTab(obj_this, tab_name) {
	var $me = $(obj_this);
	$me.parent().addClass("on").siblings().removeClass("on");
	$(".sect-pop-casol .sec-container-inner." + tab_name).removeClass("disn").siblings(".sec-container-inner").addClass("disn");
}