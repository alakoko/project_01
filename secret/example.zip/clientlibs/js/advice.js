// experience js
jQuery(function($) {
		
	$(window).on("load", function(){
		
		if ( $(".recomand-slider").length > 0 ) {
			
			$(".recomand-slider").flexslider({
				animation: "slide"
				, animationLoop: false
				, slideshow : false
				, prevText : "이전"
				, nextText : "다음"
				, itemWidth : 200
				, move: 2
				, minItems: 2
				, maxItems: 5
				, start : function(s){
					$(".recomand-slider").removeClass("not-load");
					
					try {
						if ( s.currentSlide == 0 ) {
							$(s.slides).each(function(idx){
								if ( idx < 5 ) {
									$(this).find('a').removeAttr('tabindex');
								} else {
									$(this).find('a').attr('tabindex', -1);
								}
							});
						} else {
							$(s.slides).each(function(idx){
								if ( idx >= (s.currentSlide * 2) && idx < s.currentSlide + 5 ) {
									$(this).find('a').removeAttr('tabindex');
								} else {
									$(this).find('a').attr('tabindex', -1);
								}
							});
						}
					} catch (e) {
						console.log(e.message);
					}												
					
				}
				, after : function(s) {
					
					try {
						if ( s.currentSlide == 0 ) {
							$(s.slides).each(function(idx){
								if ( idx < 5 ) {
									$(this).find('a').removeAttr('tabindex');
								} else {
									$(this).find('a').attr('tabindex', -1);
								}
							});
						} else {
							$(s.slides).each(function(idx){
								if ( idx >= (s.currentSlide * 2) && idx < (s.currentSlide * 2) + 5 ) {
									$(this).find('a').removeAttr('tabindex');
								} else {
									$(this).find('a').attr('tabindex', -1);
								}
							});
						}
					} catch (e) {
						console.log(e.message);
					}
				}
				
			});
		}
		
		if ( $(".view-slider").length > 0 ) {
			$(".view-slider").flexslider({
				animation: "slide"
				, animationLoop: true
				, slideshow : false
				, prevText : "이전"
				, nextText : "다음"
				, start : function(s){
					$(".view-slider").removeClass("not-load");
					
					try {
						s.slides.eq(s.currentSlide).find('a').removeAttr('tabindex')
							.end().find("button").removeAttr("tabindex")
							.end().siblings().find("a").attr('tabindex', -1)
							.end().find("button").attr('tabindex', -1);
					} catch (e) {
						console.log(e.message);
					}	
					
				}
				, after : function(s) {
					
					try {
						s.slides.eq(s.currentSlide).find('a').removeAttr('tabindex')
							.end().find("button").removeAttr("tabindex")
							.end().siblings().find("a").attr('tabindex', -1)
							.end().find("button").attr('tabindex', -1);
					} catch (e) {
						console.log(e.message);
					}
					
				}
			});
		}
		
		if ( $(".relprod-slider").length > 0 ) {
			$(".relprod-slider").flexslider({
				animation: "slide"
				, animationLoop: true
				, slideshow : false
				, prevText : "이전"
				, nextText : "다음"
				, minItems : 3
				, maxItems : 3
				, move		: 3
				, itemWidth : 254
				, start : function(s){
					$(".relprod-slider").removeClass("not-load");
					
					try {	
						if ( s.currentSlide == 0 ) {
							$(s.slides).each(function(idx){
								if ( idx < 3 ) {
									$(this).find('a').removeAttr('tabindex');
								} else {
									$(this).find('a').attr('tabindex', -1);
								}
							});
						} else {
							$(s.slides).each(function(idx){
								if ( idx >= (s.currentSlide * 3) && idx < s.currentSlide + 3 ) {
									$(this).find('a').removeAttr('tabindex');
								} else {
									$(this).find('a').attr('tabindex', -1);
								}
							});
						}
					} catch (e) {
						console.log(e.message);
					}
					
				}
				, after : function(s) {
					
					try {
						if ( s.currentSlide == 0 ) {
							$(s.slides).each(function(idx){
								if ( idx < 3 ) {
									$(this).find('a').removeAttr('tabindex');
								} else {
									$(this).find('a').attr('tabindex', -1);
								}
							});
						} else {
							$(s.slides).each(function(idx){
								if ( idx >= (s.currentSlide * 3) && idx < (s.currentSlide * 3) + 3 ) {
									$(this).find('a').removeAttr('tabindex');
								} else {
									$(this).find('a').attr('tabindex', -1);
								}
							});
						}
					} catch (e) {
						console.log(e.message);
					}
					
				}
			});
		}
		
	});
	
	if ( $(".radio1").length > 0 ) {
		$(".radio1").on("change", function(){
			if ( $(this).prop("checked") == true ) {
				$(this).parent().addClass("checked").siblings(".radio1-wrap").removeClass("checked");
			}
		});
	}
	
});