// experience js
jQuery(function($) {
		
	// 슬라이더
	var $slider_caro_rate33;
	var $slider_caro_rate50;
	var resizeEnd;
	
	$(window).on("load", function(){
		
		if ( $(".caro-rate33").length > 0 ) {
			
			$(".caro-rate33").width()/3
			$(".caro-rate33").flexslider({
				animation: "slide"
				, animationLoop: false
				, slideshow : false
				, prevText : "이전"
				, nextText : "다음"
				, itemWidth : 254
				, move: 3
				, minItems: 3
				, maxItems: 3
				, start : function(s){
					$(".caro-rate33").removeClass("not-load");
					
					try {
						if ( s.currentSlide == 0 ) {
							$(s.slides).each(function(idx){
								if ( idx < 3 ) {
									$(this).find('a').removeAttr('tabindex');
								} else {
									$(this).find('a').attr('tabindex', -1);
								}
							});
						} else {
							$(s.slides).each(function(idx){
								if ( idx >= (s.currentSlide * 3) && idx < s.currentSlide + 3 ) {
									$(this).find('a').removeAttr('tabindex');
								} else {
									$(this).find('a').attr('tabindex', -1);
								}
							});
						}
					} catch (e) {
						console.log(e.message);
					}
					
					$(".caro-rate33").addClass("md-mobile");
					
				}
				, after : function(s) {
					
					try {
						if ( s.currentSlide == 0 ) {
							$(s.slides).each(function(idx){
								if ( idx < 3 ) {
									$(this).find('a').removeAttr('tabindex');
								} else {
									$(this).find('a').attr('tabindex', -1);
								}
							});
						} else {
							$(s.slides).each(function(idx){
								if ( idx >= (s.currentSlide * 3) && idx < (s.currentSlide * 3) + 3 ) {
									$(this).find('a').removeAttr('tabindex');
								} else {
									$(this).find('a').attr('tabindex', -1);
								}
							});
						}
					} catch (e) {
						console.log(e.message);
					}
					
				}
				
			});
			
		}
				
		if ( $(".caro-rate50").length > 0 ) {
						
			if ( $(".mediack-mobile:visible").length > 0 ) {

				var cur_video = Math.floor((_video_current_count - 1) / 2);
				$(".caro-rate50").flexslider({
					animation: "slide"
					, animationLoop: false
					, slideshow : false
					, prevText : "이전"
					, nextText : "다음"
					, itemWidth : 152
					, move: 2
					, minItems : 2
					, maxItems : 2
					//, startAt : 3
					, start : function(s){
						$(".caro-rate50").removeClass("not-load");
						
						try {
							if ( s.currentSlide == 0 ) {
								$(s.slides).each(function(idx){
									if ( idx < 2 ) {
										$(this).find('a').removeAttr('tabindex');
									} else {
										$(this).find('a').attr('tabindex', -1);
									}
								});
							} else {
								$(s.slides).each(function(idx){
									if ( idx >= (s.currentSlide * 2) && idx < (s.currentSlide * 2) + 2 ) {
										$(this).find('a').removeAttr('tabindex');
									} else {
										$(this).find('a').attr('tabindex', -1);
									}
								});
							}
						} catch (e) {
							console.log(e.message);
						}
						
						$(".caro-rate50").addClass("md-mobile");
						$(".caro-rate50 .flex-control-paging li:eq("+ cur_video +") a").trigger("click");
						
					}
					, after : function(s) {
						
						try {
							if ( s.currentSlide == 0 ) {
								$(s.slides).each(function(idx){
									if ( idx < 2 ) {
										$(this).find('a').removeAttr('tabindex');
									} else {
										$(this).find('a').attr('tabindex', -1);
									}
								});
							} else {
								$(s.slides).each(function(idx){
									if ( idx >= (s.currentSlide * 2) && idx < (s.currentSlide * 2) + 2 ) {
										$(this).find('a').removeAttr('tabindex');
									} else {
										$(this).find('a').attr('tabindex', -1);
									}
								});
							}
						} catch (e) {
							console.log(e.message);
						}
						
					}
				});
				
			} else {
				
				var cur_video = Math.floor((_video_current_count - 1) / 4);
				$(".caro-rate50").flexslider({
					animation: "slide"
					, animationLoop: false
					, slideshow : false
					, prevText : "이전"
					, nextText : "다음"
					, itemWidth : 179
					, minItems : 4
					, maxItems : 4
					, move: 4
					//, startAt : 3
					, start : function(s){
						$(".caro-rate50").removeClass("not-load");
							
						try {
							if ( s.currentSlide == 0 ) {
								$(s.slides).each(function(idx){
									if ( idx < 4 ) {
										$(this).find('a').removeAttr('tabindex');
									} else {
										$(this).find('a').attr('tabindex', -1);
									}
								});
							} else {
								$(s.slides).each(function(idx){
									if ( idx >= (s.currentSlide * 4) && idx < (s.currentSlide * 4) + 4 ) {
										$(this).find('a').removeAttr('tabindex');
									} else {
										$(this).find('a').attr('tabindex', -1);
									}
								});
							}
						} catch (e) {
							console.log(e.message);
						}
						
						$(".caro-rate50").addClass("md-mobile-no");
						$(".caro-rate50 .flex-control-paging li:eq("+ cur_video +") a").trigger("click");
						
					}
					, after : function(s) {
						
						try {
							if ( s.currentSlide == 0 ) {
								$(s.slides).each(function(idx){
									if ( idx < 4 ) {
										$(this).find('a').removeAttr('tabindex');
									} else {
										$(this).find('a').attr('tabindex', -1);
									}
								});
							} else {
								$(s.slides).each(function(idx){
									if ( idx >= (s.currentSlide * 4) && idx < (s.currentSlide * 4) + 4 ) {
										$(this).find('a').removeAttr('tabindex');
									} else {
										$(this).find('a').attr('tabindex', -1);
									}
								});
							}
						} catch (e) {
							console.log(e.message);
						}
						
					}
				});
				
			}
		}
		
		if ( $(".slider1").length > 0 ) {
			$(".slider1").flexslider({
				animation: "slide"
				, animationLoop: true
				, slideshow : false
				, prevText : "이전"
				, nextText : "다음"
					
				, start : function(s){
					$(".slider1").removeClass("not-load");
					
					try {
						s.slides.eq(s.currentSlide).find('a').removeAttr('tabindex')
							.end().find("button").removeAttr("tabindex")
							.end().siblings().find("a").attr('tabindex', -1)
							.end().find("button").attr('tabindex', -1);
					} catch (e) {
						console.log(e.message);
					}
					
				}
				, after : function(s) {
					
					try {
						s.slides.eq(s.currentSlide).find('a').removeAttr('tabindex')
							.end().find("button").removeAttr("tabindex")
							.end().siblings().find("a").attr('tabindex', -1)
							.end().find("button").attr('tabindex', -1);
					} catch (e) {
						console.log(e.message);
					}
					
				}
			});
		}
		
	});
	
	var flag1 = true;
	var flag2 = true;
	$(window).on("resize", function(){
		
		if ( $(".caro-rate50").length > 0 ) {
			
			if ( $(".mediack-mobile:visible").length > 0 ) {
				
				if ( $(".caro-rate50").hasClass("md-mobile") == false ) {
					$slider_caro_rate50 = $(".caro-rate50").data("flexslider");
					$slider_caro_rate50.vars.itemWidth = 147;
					$slider_caro_rate50.vars.move = 2;
					$slider_caro_rate50.vars.minItems = 2;
					$slider_caro_rate50.vars.maxItems = 2;
					$slider_caro_rate50.doMath();
					$(".caro-rate50").removeClass("md-mobile-no").addClass("md-mobile");
					
					try {
						
						if ( $slider_caro_rate50.currentSlide == 0 ) {
							$($slider_caro_rate50.slides).each(function(idx){
								if ( idx < 2 ) {
									$(this).find('a').removeAttr('tabindex');
								} else {
									$(this).find('a').attr('tabindex', -1);
								}
							});
						} else {
							$($slider_caro_rate50.slides).each(function(idx){
								if ( idx >= ($slider_caro_rate50.currentSlide * 2) && idx < ($slider_caro_rate50.currentSlide * 2) + 2 ) {
									$(this).find('a').removeAttr('tabindex');
								} else {
									$(this).find('a').attr('tabindex', -1);
								}
							});
						}
						
						$slider_caro_rate50.vars.after = function(s) {
							if ( s.currentSlide == 0 ) {
								$(s.slides).each(function(idx){
									if ( idx < 2 ) {
										$(this).find('a').removeAttr('tabindex');
									} else {
										$(this).find('a').attr('tabindex', -1);
									}
								});
							} else {
								$(s.slides).each(function(idx){
									if ( idx >= (s.currentSlide * 2) && idx < (s.currentSlide * 2) + 2 ) {
										$(this).find('a').removeAttr('tabindex');
									} else {
										$(this).find('a').attr('tabindex', -1);
									}
								});
							}
						}
						
					} catch (e) {
						console.log(e.message);
					}
						
					clearTimeout();
					setTimeout(function() {
						var cur_video = Math.floor((_video_current_count - 1) / 2);
						$(".caro-rate50 .flex-control-paging li:eq("+ cur_video +") a").trigger("click");
					}, 600);
					
				}
				
			} else {
				
				if ( $(".caro-rate50").hasClass("md-mobile-no") == false ) {
					$slider_caro_rate50 = $(".caro-rate50").data("flexslider");
					$slider_caro_rate50.vars.itemWidth = 179;
					$slider_caro_rate50.vars.move = 4;
					$slider_caro_rate50.vars.minItems = 4;
					$slider_caro_rate50.vars.maxItems = 4;
					$slider_caro_rate50.doMath();
					$(".caro-rate50").addClass("md-mobile-no").removeClass("md-mobile");
					
					try {
						if ( $slider_caro_rate50.currentSlide == 0 ) {
							$($slider_caro_rate50.slides).each(function(idx){
								if ( idx < 4 ) {
									$(this).find('a').removeAttr('tabindex');
								} else {
									$(this).find('a').attr('tabindex', -1);
								}
							});
						} else {
							$($slider_caro_rate50.slides).each(function(idx){
								if ( idx >= ($slider_caro_rate50.currentSlide * 4) && idx < ($slider_caro_rate50.currentSlide * 4) + 4 ) {
									$(this).find('a').removeAttr('tabindex');
								} else {
									$(this).find('a').attr('tabindex', -1);
								}
							});
						}
						
						$slider_caro_rate50.vars.after = function(s) {
							if ( s.currentSlide == 0 ) {
								$(s.slides).each(function(idx){
									if ( idx < 4 ) {
										$(this).find('a').removeAttr('tabindex');
									} else {
										$(this).find('a').attr('tabindex', -1);
									}
								});
							} else {
								$(s.slides).each(function(idx){
									if ( idx >= (s.currentSlide * 4) && idx < (s.currentSlide * 4) + 4 ) {
										$(this).find('a').removeAttr('tabindex');
									} else {
										$(this).find('a').attr('tabindex', -1);
									}
								});
							}
						}
					
					} catch (e) {
						console.log(e.message);
					}
					
					clearTimeout();
					setTimeout(function() {
						var cur_video = Math.floor((_video_current_count - 1) / 4);
						$(".caro-rate50 .flex-control-paging li:eq("+ cur_video +") a").trigger("click");
					}, 600);
					
				}
				
			}
			
		}
		
	});
		
	if ( $(".pop1-area").length > 0 ) {
		$(".btn-pop-close", $(".pop1-area")).on("focusout", function(){
			fnClosePopImg("pop1-area");
			$("." + $(this).data("focusTo")).eq($(this).data("focusEq")).focus();
		});
	}
	
});
